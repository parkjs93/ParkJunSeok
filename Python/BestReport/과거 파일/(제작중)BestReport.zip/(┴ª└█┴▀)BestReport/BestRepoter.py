import tkinter
from tkinter import filedialog
from openpyxl import Workbook, load_workbook
from tkinter.ttk import LabelFrame

#######윈도우 생성#######
window=tkinter.Tk()
window.title("Best Reporter")
window.geometry("300x200+800+50")
window.resizable(False,False)

#######동작 함수#######
def fileOpen():
    #UI 화면에 진행 상황 출력 시키기
    log_text.config(text="시작")
    #파일 탐색기 오픈해서 선택한 파일의 경로를 filename에 저장  
    filename=filedialog.askopenfilename(initialdir="",title="Select File")
    #선택한 파일 
    log_text.config(text=filename)
    
    #######엑셀 변수 생성#######    row =1,2,3... // column=a,b,c.....
    newWb=Workbook()            #새로운 워크북 생성(우테 취합용)
    wb=load_workbook(filename)  #버튼으로 선택한 엑셀 파일 불러오기

    #버그리포트 취합 엑셀 전체 시트 중 뒤에서 5번째까지 이름 가져오기    
    for ws,i in zip(wb.sheetnames, range(1,len(wb.sheetnames)-1)): 

        brws = newWb.create_sheet(ws)
        print(ws)   #워크시트 이름 하나씩 출력
        log_text.config(text=ws)
        count=2
        brws.cell(row=1,column=2).value="JIRA 링크"
        brws.cell(row=1,column=3).value="처리 여부"
        brws.cell(row=1,column=4).value="등급"
        brws.cell(row=1,column=5).value="등록자"
        brws.cell(row=1,column=6).value="글번호"
        brws.cell(row=1,column=7).value="담당자"

        for j in tuple(wb[ws].rows):        #해당 워크 시트 중 열의 끝까지 반복
            if (j[5].value == "JIRA 등록"): #해당 워크 시트의 5행의 열이 "JIRA 등록일 때"
                print(j[1].value)
                print(j[7].value)  #참일 경우 1열의 "글번호" 7열의 "JIRA 링크" 출력
                brws.cell(row=count,column=2).value=j[7].value  #JIRA 링크
                brws.cell(row=count,column=3).value=j[5].value  #처리 여부
                brws.cell(row=count,column=4).value=j[6].value  #등급
                brws.cell(row=count,column=5).value=j[2].value  #등록자
                brws.cell(row=count,column=6).value=j[1].value  #글번호
                brws.cell(row=count,column=7).value=j[4].value  #담당자
                count=count+1
            elif (j[5].value =="본섭수정"):
                print(j[1].value)
                print(j[3].value)   #글번호와 내용 부분 출력
                brws.cell(row=count,column=2).value=j[7].value  #JIRA 링크
                brws.cell(row=count,column=3).value=j[5].value  #처리 여부
                brws.cell(row=count,column=5).value=j[2].value  #등록자
                brws.cell(row=count,column=6).value=j[1].value  #글번호
                brws.cell(row=count,column=7).value=j[4].value  #담당자
                count=count+1
            elif(j[5].value=="NextUpdate"):
                print(j[1].value)
                print(j[7].value)
                brws.cell(row=count,column=2).value=j[7].value  #JIRA 링크
                brws.cell(row=count,column=3).value=j[5].value  #처리 여부
                brws.cell(row=count,column=5).value=j[2].value  #등록자
                brws.cell(row=count,column=6).value=j[1].value  #글번호
                brws.cell(row=count,column=7).value=j[4].value  #담당자
                count=count+1
            
        print("---")
            
    log_text.config(text="끝")
    newWb.save("BestTester.xlsx")

#######라벨 생성#######
#메인 라벨
mainLabelFrame=LabelFrame(window, text="우수 테스터 선발")
mainLabelFrame.place(relx=0.01,relwidth=0.98,relheight=0.99)

#서브 라벨1
subLabelFrame1=LabelFrame(mainLabelFrame, text="Setting")
subLabelFrame1.place(relx=0.01, relwidth=0.98, relheight=0.35)
#서브 라벨2
subLabelFrame2=LabelFrame(mainLabelFrame, text="Result")
subLabelFrame2.place(relx=0.01, rely=0.36, relwidth=0.98, relheight=0.63)

#######버튼 생성#######
#파일 선택 버튼
fileopenBtn=tkinter.Button(subLabelFrame1,text="파일 열기",width="30",command=fileOpen)
fileopenBtn.place(relx=0.1,rely=0.1)

#######result 라벨 출력#######
#result 라벨 표시
log_text=tkinter.Label(subLabelFrame2,wraplength=280,justify="left", bg="blue")
log_text.place(relx=0.01,rely=0.01, relwidth=0.98, relheight=0.98)

window.mainloop()