import tkinter
from tkinter.ttk import LabelFrame

#######윈도우 생성#######
window=tkinter.Tk()
window.title("Best Reporter")
window.geometry("300x400+200+100")
window.resizable(False,False)

#######라벨 생성#######
#메인 라벨
mainLabelFrame=LabelFrame(window, text="우수 테스터 선발")
mainLabelFrame.place(relx=0.01,relwidth=0.98,relheight=0.99)

#서브 라벨1
subLabelFrame1=LabelFrame(mainLabelFrame, text="Setting")
subLabelFrame1.place(relx=0.01, relwidth=0.98, relheight=0.75)
#서브 라벨2
subLabelFrame2=LabelFrame(mainLabelFrame, text="Result")
subLabelFrame2.place(relx=0.01, rely=0.76, relwidth=0.98, relheight=0.23)

window.mainloop()