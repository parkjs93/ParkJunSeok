import tkinter
import tkinter.messagebox
import tkinter.ttk
from tkinter import filedialog
from openpyxl import load_workbook
import pathlib
import os
from selenium import webdriver
import chromedriver_autoinstaller

###윈도우 생성하기###
window = tkinter.Tk()
window.title("Description Check Auto Tool")
window.geometry("350x400+200+200")
window.wm_iconbitmap('jacso2.ico') #아이콘 생성
window.resizable(False,False)

###노트북(바탕) 만들기###
notebook = tkinter.ttk.Notebook(window)
notebook.place(relx=0.01,relwidth=0.98, relheight=0.91)

#UI 부분
frame_main = tkinter.Frame(window)
notebook.add(frame_main, text="Main")
frame_sentence = tkinter.Frame(window)
frame_item = tkinter.Frame(window)

#크롬 드라이버 확인 후 업데이트 
tkinter.messagebox.showinfo(title="Wait!",message="크롬 드라이버 체크 중 입니다. \n확인 버튼 클릭 후 잠시만 기다려주세요.")
chromedriver_autoinstaller.install()

######초반 엑셀 작업부분######
#지정된 파일 불러오기 (뒤 인자값 xlsm 데이터 적용을 위함) 
wb=load_workbook("ScriptCheck.xlsm",read_only=False,keep_vba=True)#VBA 매크로 형태로 파일 오픈할 때 선언
ws=wb['script']

######비슷한 구조의 대사함수 리스트화 하기######
def funcLoad():
    funcWb=load_workbook("sayFunctionList.xlsx",data_only=True)
    funcWs=funcWb["sayfunc"]
    # 첫 번째 인자가 대사
    global sayfunc
    sayfunc = []
    # 두 번째 인자가 대사
    global sayfunc2
    sayfunc2 = []
    # 세 번째 인자가 대사
    global sayfunc3
    sayfunc3 = []
    # 네 번째 인자가 대사 
    global sayfunc4
    sayfunc4 = []

    fcount =0
    #if(len(sayfunc) == 0 and len(sayfunc2) == 0 and len(sayfunc3) == 0 and len(sayfunc4) == 0):
    for func in funcWs.rows:
        if(funcWs.cell(row=2+fcount, column=1).value!=None):
            sayfunc.append(funcWs.cell(row=2+fcount, column=1).value)
        
        if(funcWs.cell(row=2+fcount, column=2).value != None):
            sayfunc2.append(funcWs.cell(row=2+fcount, column=2).value)
        
        if(funcWs.cell(row=2+fcount, column=3).value != None):
            sayfunc3.append(funcWs.cell(row=2+fcount, column=3).value)
        
        if(funcWs.cell(row=2+fcount, column=4).value != None):
            sayfunc4.append(funcWs.cell(row=2+fcount, column=4).value)
        fcount+=1

    return sayfunc, sayfunc2, sayfunc3, sayfunc4


#엑셀에 값이 있는지 확인 후 빈 값 아니면 지우기
def resetexcel():
    row_check=5
    for r in ws.rows:
        for c in range(6):
            if(ws.cell(row=row_check, column=2+c).value == None):
                pass
            else:
                ws.cell(row=row_check, column=2+c).value = None
        row_check += 1

#####함수 부분####
#프레임 지워주기
def frame_clear():
    if(notebook.tabs() == ('.!frame',)):
        notebook.forget(frame_main)
    elif(notebook.tabs() == ('.!frame2',)):
        notebook.forget(frame_sentence)
    elif(notebook.tabs() == ('.!frame3',)):
        notebook.forget(frame_item)
    else:
        pass

#메뉴 선택 후 프레임 출력
def frame_active(framename):
    ####국내####
    if(framename == "sentence"):
        frame_clear()
        notebook.add(frame_sentence, text="Script")
    elif(framename == "item"):
        frame_clear()
        notebook.add(frame_item, text="Img File")
    else:
        frame_clear()
        notebook.add(frame_main, text="Main")
    
#대사 부분만 출력하기
def extraction(text):
    find_funcIndex = text.find("(")
    fun_sentence = text[:find_funcIndex]
    fun_sentence = fun_sentence.replace(" ","")
    fun_sentence = fun_sentence.replace("\t","")
    if(fun_sentence.find(".") != -1):
        fun_sentence = fun_sentence[fun_sentence.find(".")+1:]
    elif(fun_sentence.find("=") != -1):
        fun_sentence = fun_sentence[fun_sentence.find("=")+1:]
    # print(fun_sentence)

    #대사 함수 추출해서 저장하기
    for fs in range(0,len(sayfunc)):
        #print(sayfunc[fs],fun_sentence)
        #바로 대사 출력
        if (sayfunc[fs] == fun_sentence): 
            data_sentence = text[text.find("("):]
            print(data_sentence)
            data_sentence = data_sentence.replace(fun_sentence,"")
            data_sentence = data_sentence.split('",')            
            data_sentence = data_sentence[0]
            data_sentence = data_sentence[data_sentence.find('"'):]
            return data_sentence.replace('"','')
        
    for fs2 in range(0,len(sayfunc2)):
        # print("------------------------------------------")
        # print(sayfunc2[fs2],fun_sentence)
        if(sayfunc2[fs2] == fun_sentence):
            data_sentence = text[text.find("("):]
            data_sentence = data_sentence.replace(fun_sentence,"")
            data_sentence = data_sentence.split('",')
            data_sentence = data_sentence[1][data_sentence[1].find('"'):]
            return data_sentence.replace('"','')

    for fs3 in range(0,len(sayfunc3)):
        # print("------------------------------------------")
        # print(sayfunc3[fs3],fun_sentence)
        if(sayfunc3[fs3] == fun_sentence):
            data_sentence = text[text.find("("):]
            data_sentence = data_sentence.replace(fun_sentence,"")
            data_sentence = data_sentence.split('",')
            data_sentence = data_sentence[2][data_sentence[2].find('"'):]
            return data_sentence.replace('"','')
                           
    for fs4 in range(0,len(sayfunc4)):
        # print("------------------------------------------")
        # print(sayfunc4[fs4],fun_sentence)
        if(sayfunc4[fs4] == fun_sentence):
            data_sentence = text[text.find("("):]     
            data_sentence = data_sentence.replace(fun_sentence,"")
            data_sentence = data_sentence.split('",')
            data_sentence = data_sentence[3][data_sentence[3].find('"'):]
            return data_sentence.replace('"','')

#img 변환 파일 경로 찾고 replace 시켜주는 함수(아이템 카테고리(파일찾기), 코드 리스트)
def imgFileEdit(category,codeIdList):
    itemInfoLlst =[]
    path = pathlib.Path("Img2Excel_Folder/"+category+".xls") # xls 파일 경로 저장
    #파일 없을 경우 예외 처리
    try:
        with open(path,"r",encoding="utf8") as file: #utf16은 .s파일 오픈할 때만... .txt
            try:
                lines = file.readlines()          #파일의 모든 줄을 읽어 lines 리스트에 저장
            except UnicodeError:                    #UnicodeError 발생 시 utf16로 인코딩 진행
                with open(path,"r",encoding="utf16") as file:
                    lines = file.readlines()
    except FileNotFoundError:
        tkinter.messagebox.showerror(title="Error", message="[FileNotFoundError]\nImg2Excel_Folder 폴더에 "+category+".xls이 존재하지 않습니다.")
    #Etc img 파일의 경우 파일 트리 구조가 다르게 구성되어있어 구분
    if (category =="Etc"):
        #변환된 IMG의 내용이 저장되며 문자열 특정 단어 치환
        for ls in range(0, len(lines)):
            a = lines[ls].replace("<tr><td>","")
            a = a.replace("Etc","")
            a = a.replace("</td><td>","//")
            a = a.replace("</td></tr>","")
            a = a.replace("\n"," ")
            a = a[2:]

            for code in range(0, len(codeIdList)):
                if(a.find(str(codeIdList[code])) != -1):
                    nameIndex = a.find("//")
                    itemName=a[:nameIndex]
                    if(itemName == str(codeIdList[code])):
                        a_slice=a[nameIndex+1:]

                        descIndex = a_slice.find("//")
                        itemDesc=a_slice[descIndex+2:]
                        itemInfoLlst.append("["+itemName+"] /"+itemDesc)
        return itemInfoLlst

    #Eqp img 파일의 경우 파일 데이터 트리 구조가 다르게 구성되어있어 구분
    elif(category =="Eqp"):
        for ls in range(0, len(lines)):
            a = lines[ls].replace("<tr><td>","")
            a = a.replace("</td><td>","//")
            a = a.replace("</td></tr>","")
            a = a.replace("\n"," ")
            aindex = a.find("//")
            a = a[aindex+2:]
            aindex = a.find("//")
            a = a[aindex+2:]            
     
            for code in range(0, len(codeIdList)):
                if(a.find(str(codeIdList[code])) != -1):
                    nameIndex = a.find("//")
                    itemName=a[:nameIndex]
                    if(itemName == str(codeIdList[code])):
                        a_slice=a[nameIndex+1:]

                        descIndex = a_slice.find("//")
                        itemDesc=a_slice[descIndex+2:]
                        itemInfoLlst.append("["+itemName+"] /"+itemDesc)
                    else:
                        print(itemName)
        return itemInfoLlst

    #eqp, etc 이외의 아이템, 스킬은 따로 문자열 처리
    else:
        #변환된 IMG의 내용이 저장되며 문자열 특정 단어 치환
        for ls in range(0, len(lines)):
            #print(lines[ls])
            a = lines[ls].replace("<tr><td>","")
            a = a.replace("</td><td>","//")
            a = a.replace("</td></tr>","")
            a = a.replace("\n"," ")
            
            for code in range(0, len(codeIdList)):
                if(a.find(str(codeIdList[code])) != -1):
                    nameIndex = a.find("//")
                    itemName=a[:nameIndex]
                    if(itemName == str(codeIdList[code])):
                        print(itemName)
                        a_slice=a[nameIndex+1:]

                        descIndex = a_slice.find("//")
                        itemDesc=a_slice[descIndex+2:]
                        itemInfoLlst.append("["+itemName+"] /"+itemDesc)
                    else:
                        print(itemName)
        return itemInfoLlst

#파일 오픈 함수 (대사 오타)
def txtFileOpen(testFile, codeIdList):      #codeIDList = text 창에 입력한 item id 리스트
    print("1")
    resetexcel()
    #스크립트
    if(testFile=="script"):
        if(codeIdList =="choice"):
            funcLoad()
            # print("sayfunc : ")
            # print(sayfunc)
            # print("sayfunc2 : ")
            # print(sayfunc2)
            # print("sayfunc3 : ")
            # print(sayfunc3)
            # print("sayfunc4 : ")
            # print(sayfunc4)
            # 스크립트 리스트 저장 할 공간
            scriptChoice=[]
            #파일 탐색기 오픈
            txtfilename = filedialog.askopenfilename(initialdir="",title="Select File")
            if(txtfilename == ""):
                #파일 탐색기 오픈 후 취소 할 경우 동작하지 않도록 하기 위해
                tkinter.messagebox.showerror(title="Error",message="Script File을 선택하지 않았습니다.\n다시 시도해주세요.")
            elif(txtfilename != ""):
                path = pathlib.Path(txtfilename)
                scriptChoice.append(path)
                for sc in range(len(scriptChoice)):
                    scriptListbox.insert(sc,scriptChoice[sc])

        elif(codeIdList == "start"):
            if (scriptListbox.size() != 0):
                #파일 오픈하여 lines 리스트 변수에 저장
                j=5
                strat = scriptListbox.size()
                scriptChoice=scriptListbox.get(0,strat)
                for scfunc in range(len(scriptChoice)):
                    #파일명 추출하기 
                    scriptTitleSplit = str(scriptChoice[scfunc]).split("\\")
                    scriptTitle=scriptTitleSplit[len(scriptTitleSplit)-1]

                    #파일 오픈해서 한 줄 씩 읽기
                    with open(scriptChoice[scfunc],"r",encoding="utf8") as file: #utf16은 .s파일 오픈할 때만... .txt
                        try:
                            lines = file.readlines()          #파일의 모든 줄을 읽어 lines 리스트에 저장
                        except UnicodeError:                    #UnicodeError 발생 시 utf16로 인코딩 진행
                            with open(scriptChoice[scfunc],"r",encoding="utf16") as file:
                                lines = file.readlines()
                        
                        #한 줄 씩 엑셀에 값 입력하기
                        for line in lines:
                            scriptSentence = extraction(line)   #대사만 추출해내는 함수 동작
                            if(scriptSentence != None):
                                ws.cell(row=j, column=2).value = scriptSentence
                                ws.cell(row=j, column=3).value = scriptTitle
                                j+=1
                            else:
                                pass
                #리스트 초기화
                scriptListbox.delete(0,tkinter.END)

                try:
                    wb.save("ScriptCheck.xlsm")
                except PermissionError:
                    tkinter.messagebox.showerror(title="Error",message="ScriptCheck.xlsm 파일이 실행 중 입니다.\n\n종료 후 다시 동작 버튼을 눌러주세요.\n(PermissionError)")
                os.system("start ScriptCheck.xlsm")  #노트북에선 주석처리  
                print("end")

            elif(scriptListbox.size()==0):
                tkinter.messagebox.showerror(title="Error",message="선택된 스크립트 파일이 없습니다.\n\n파일을 선택해주세요")

        elif(codeIdList=="delete"):
            if(scriptListbox.size()==0):
                tkinter.messagebox.showerror(title="Error",message="선택된 스크립트 파일이 없습니다.\n\n파일을 선택해주세요")
            elif(scriptListbox.size()!=0):
                scriptListbox.delete(0)

    #img
    elif(testFile == "img"):
        #print("img로 넘어옴")
        code_skillList=[]
        code_itemList=[]
        eqpList = []
        etcList = []
        resultList = [] #extend로 붙이기
        #codeIdList에 포함된 리스트 인덱스 값의 길이(코드 길이)가 7일 경우 (장비, 소비, 설치, 기타, 캐시, NPC) / 7이 아닐 경우(skill)
        for targetcode in codeIdList:
            if(len(targetcode)==7): #skill인지 아닌지 구분하기 위함
                if(targetcode[0] == "1"): #코드의 첫 글자가 1일 경우 eqpList 리스트에 저장
                    eqpList.append(targetcode)
                elif(targetcode[0] == "4"): #코드의 첫 글자가 4일 경우 etcList 리스트에 저장
                    etcList.append(targetcode)
                else:
                    code_itemList.append(targetcode) #이 외의 코드는 code_itemList에 저장
            elif(len(targetcode)!=7):   #7글자가 아닐 경우 skill ID로 판단
                code_skillList.append(targetcode)   
            else:
                pass

        #추출한 결과 합치기 (append로 할 경우 리스트 안에 리스트가 추가되는 형식이라 extend로 추가)
        if(eqpList != []):
            resultList.extend(imgFileEdit("Eqp",eqpList))
            resultList.extend(imgFileEdit("Skill",eqpList))
        if(code_itemList !=[]):
            resultList.extend(imgFileEdit("Consume",code_itemList))
            resultList.extend(imgFileEdit("Ins",code_itemList))
            resultList.extend(imgFileEdit("Npc",code_itemList))
            resultList.extend(imgFileEdit("Cash",code_itemList))
            resultList.extend(imgFileEdit("Pet",code_itemList))
            resultList.extend(imgFileEdit("PetDialog",code_itemList))
            resultList.extend(imgFileEdit("Skill",code_itemList))
        if(code_skillList != []):
            resultList.extend(imgFileEdit("Skill",code_skillList))
        if(etcList != []):
            resultList.extend(imgFileEdit("Etc",etcList))
            resultList.extend(imgFileEdit("Skill",etcList))

        #합친 결과 시트에 작성하기
        for listIndex in range(0,len(resultList)):
            resultID = resultList[listIndex].split("/")
            ws.cell(row =5+listIndex, column =2 ).value = resultID[1]
            ws.cell(row =5+listIndex, column =3 ).value = resultID[0]
            #파일 저장(엑셀 파일이 실행중인 경우 예외처리)
        try:
            wb.save("ScriptCheck.xlsm")
        except PermissionError:
            tkinter.messagebox.showerror(title="Error",message="ScriptCheck.xlsm 파일이 실행 중 입니다.\n\n종료 후 다시 동작 버튼을 눌러주세요.\n(PermissionError)")
        os.system("start ScriptCheck.xlsm")  #노트북에선 주석처리  
        print("end")

    else:
        print("error : "+str(testFile))



#줄바꿈 기준으로 값 저장시키기
def wordList(idcode):
    itemcode = []
    for id in range(0, len(idcode)):
        itemcode_index = idcode.find("\n")
        itemcode.append(str(idcode[:itemcode_index]))
        idcode = idcode[itemcode_index+1:]
        if(len(idcode)==0):
            #리스트 중 빈 값이 있으면 모든 값 출력되고있어 마지막에 빈 값 제거
            for nullId in range (0,len(itemcode)):
                if(itemcode[nullId]==""):
                    itemcode.remove("")
                else:
                    pass
            return itemcode
    
#Text 박스에서 입력받은 값 리스트에 저장시키기
def codeInsert(): 
    codeEntry = korItem_Entry.get(1.0, "end") 
    codeIdList=wordList(codeEntry)
    print(codeIdList)
    txtFileOpen("img",codeIdList)

def codeInsert_reset(): 
    korItem_Entry.delete("1.0","end")
    korItem_Entry.insert(1.0,"[사용방법]\n\n\n1).img 파일을 .xls 파일로 변환\n\n2)폴더 내 Img2Excel_Folder에 변환된 파일 추가\n\n3)검색할 코드 입력\n\n4)동작 버튼 클릭\n\n(해당 부분 모두 지우고 입력)")

def help():
    os.system("start https://confluence.nexon.com/pages/viewpage.action?pageId=718024641")

def custom():
    os.system("start sayFunctionList.xlsx")

###메뉴바 추가###
menubar = tkinter.Menu(window)

menu_kor = tkinter.Menu(menubar, tearoff=0)
menu_kor.add_command(label="Script", command=lambda:frame_active("sentence"))
menu_kor.add_command(label="Img File", command=lambda:frame_active("item"))
menubar.add_cascade(label="[맞춤법 및 번역 검사]", menu=menu_kor)
menu_kor.add_separator()
menu_kor.add_cascade(label="Setting(script)", command=custom)
menu_kor.add_cascade(label="Help", command=help)
# menu_kor.add_cascade(label="Main", command=frame_reset) 

window.config(menu=menubar)

###페이지 라벨 만들기###
#메인 라벨
mainFrame = tkinter.LabelFrame(frame_main)
mainFrame.place(relx=0.01, relwidth=0.98, relheight=0.99)
nameLabel=tkinter.Label(window, text=" @hjong  @jeonyul  @parkjs", bg="black",fg="white")
nameLabel.place(relx=0.5,rely=0.93)

main_textLable = tkinter.Label(frame_main, text="DCAT4 (Description Check Auto Tool Ver.4)\n\n맞춤법 검사 및 미번역 체크 관리 툴!\n\n\n상단의 메뉴에서 테스트 항목을 선택해주세요!", justify="left")
main_textLable.place(relx=0.05,rely=0.3)

#대사 맞춤법 검사 라벨
korScriptLF=tkinter.LabelFrame(frame_sentence)
korScriptLF.place(relx=0.01,relwidth=0.98,relheight=0.99)
korScript_txt=tkinter.Label(korScriptLF, text="원하는 대사 스크립트 파일을 선택해주세요.", justify="left")
korScript_txt.place(relx=0.1, rely=0.03)
korScript_txt=tkinter.Label(korScriptLF, text="(국내) ACData_KR\DataSvr\Script\n\n(해외) ACData_담당 국가\\DataSvr\Script", justify="left")
korScript_txt.place(relx=0.1, rely=0.16)
korfileOpenBtn1 = tkinter.Button(korScriptLF, width=12, text="파일 선택", command=lambda:txtFileOpen("script","choice"))
korfileOpenBtn1.place(relx=0.02, rely=0.4)
korfileOpenBtn2 = tkinter.Button(korScriptLF, width=12, text="대사 추출", command=lambda:txtFileOpen("script","start"))
korfileOpenBtn2.place(relx=0.33, rely=0.4)
korfileOpenBtn3 = tkinter.Button(korScriptLF, width=12, text="최상단 삭제", command=lambda:txtFileOpen("script","delete"))
korfileOpenBtn3.place(relx=0.64, rely=0.4)


#선택된 스크립트 보여줄 리스트 박스
scriptListbox = tkinter.Listbox(korScriptLF, selectmode="extended", width=42,height=8,relief="solid")
scriptListbox.place(relx=0.02, rely=0.5)

#스크롤 바로 리스트 박스 스크롤
scriptScroll1=tkinter.Scrollbar(korScriptLF,orient="vertical")
scriptScroll1.config(command=scriptListbox.yview)
scriptScroll1.place(relx=0.925, rely=0.5, relheight=0.42)
scriptScroll2=tkinter.Scrollbar(korScriptLF,orient="horizontal")
scriptScroll2.config(command=scriptListbox.xview)
scriptScroll2.place(relx=0.02,rely=0.92, relwidth=0.9)
scriptListbox.config(yscrollcommand=scriptScroll1.set)
scriptListbox.config(xscrollcommand=scriptScroll2.set)


#아이템 맞춤법 검사 라벨 
korItemLF=tkinter.LabelFrame(frame_item)
korItemLF.place(relx=0.01,relwidth=0.98,relheight=0.99)
korItem_Entry = tkinter.Text(korItemLF, width=30, height=23)
korItem_Entry.insert(1.0,"[사용방법]\n\n\n1).img 파일을 .xls 파일로 변환\n\n2)폴더 내 Img2Excel_Folder에 변환된 파일 추가\n\n3)검색할 코드 입력\n\n4)동작 버튼 클릭\n\n(해당 부분 모두 지우고 입력)")
korItem_Entry.place(relx=0.01, rely=0.01)
korItem_EntryBtn = tkinter.Button(korItemLF, width=10, text="동작", command=codeInsert)
korItem_EntryBtn.place(relx=0.7, rely=0.02)
korItem_EntryBtn2 = tkinter.Button(korItemLF, width=10, text="초기화", command=codeInsert_reset)
korItem_EntryBtn2.place(relx=0.7, rely=0.12)

window.mainloop()
